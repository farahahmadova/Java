package com.farahahmadova.methodsandclasses;

public class Musicians {
    //attribute
    public String names;
   public String instruments;
   public Integer age;

    public Musicians(String names, String instruments, Integer age) {
        this.names = names;
        this.instruments = instruments;
        this.age = age;
        System.out.println("constructor called");
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public String getInstruments() {
        return instruments;
    }

    public void setInstruments(String instruments) {
        this.instruments = instruments;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
